// SHAMELESSLY TAKEN FROM https://rosettacode.org/wiki/CRC-32#C.2B.2B
// (UNDER GNU FDL 1.2)

#ifndef IMPORT_SRC_CRC32_H
#define IMPORT_SRC_CRC32_H

#if MAPPING == SW_MAPPING || defined(SPACE_SIMULATION_RELEASE) || defined(SPACE_SIMULATION_MONITORING) || defined(SPACE_SIMULATION_DEBUG)

#include <algorithm>
#include <array>
#include <cstdint>
#include <numeric>

/**
 * Internal function used by crc32().
 */
std::array<std::uint_fast32_t, 256> generate_crc_lookup_table() noexcept;

/**
 * Calculates the CRC for any sequence of values. The values
 *
 * @example
 * int main()
 * {
 *   auto const s = std::string{"The quick brown fox jumps over the lazy dog"};
 *   std::cout << std::hex << std::setw(8) << std::setfill('0') << crc32(s.begin(), s.end()) << '\n';
 * }
 * @endexample
 * 
 * @note A pointer is an iterator. Also note that 'last' is a
 * past-the-end iterator ('last' has to point to the element past
 * the last element).
 * 
 * @example
 * int main()
 * {
 *   // An array of 8-bit values. If this were an array of values
 *   // greater than 8-bits, cast it to an 8-bit array and make sure
 *   // 'last' is the BYTE past the last BYTE in the sequence.
 *   const uint8_t foo[] = {0, 1, 2, 3};
 *   std::cout << crc32(foo, &foo[4]) << '\n';
 *   //                           ^
 *   //                     Past-the-end
 * }
 * @endexample
 */
template <typename InputIterator>
std::uint_fast32_t crc32(InputIterator first, InputIterator last)
{
  // Generate lookup table only on first use then cache it - this is thread-safe.
  static auto const table = generate_crc_lookup_table();

  // Calculate the checksum - make sure to clip to 32 bits, for systems that don't
  // have a true (fast) 32-bit type.
  return std::uint_fast32_t{0xFFFFFFFFuL} &
    ~std::accumulate(first, last,
      ~std::uint_fast32_t{0} & std::uint_fast32_t{0xFFFFFFFFuL},
        [](std::uint_fast32_t checksum, std::uint_fast8_t value)
          { return table[(checksum ^ value) & 0xFFu] ^ (checksum >> 8); });
}

#else // MAPPING == SW_MAPPING || defined(SPACE_SIMULATION_RELEASE) || defined(SPACE_SIMULATION_MONITORING) || defined(SPACE_SIMULATION_DEBUG)
#define generate_crc_lookup_table
#define crc32(...)
#endif // MAPPING == SW_MAPPING || defined(SPACE_SIMULATION_RELEASE) || defined(SPACE_SIMULATION_MONITORING) || defined(SPACE_SIMULATION_DEBUG)

#endif // !IMPORT_SRC_CRC32_H
