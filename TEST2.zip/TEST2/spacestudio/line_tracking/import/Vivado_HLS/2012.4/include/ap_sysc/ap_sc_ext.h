/* -*- sysc -*-*/
/*
 * Copyright (C) 2011 XILINX, Inc. 
 *
 *
 */

#ifndef __AP_SC_EXT_H__
#define __AP_SC_EXT_H__

//for simulation
#define wait_until(x) while(!x) wait();

#include "hls_bus_if.h"

#endif
