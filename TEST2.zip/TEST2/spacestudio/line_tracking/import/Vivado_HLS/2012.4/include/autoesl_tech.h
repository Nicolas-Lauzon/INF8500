/* autopilot_tech.h */
/*
 * Copyright (C) 2011 XILINX, Inc. 
 *
 * $Id$
 */


#ifndef _AUTOPILOT_TECH_H_
#define _AUTOPILOT_TECH_H_

#include "ap_cint.h"
#include "ap_utils.h"

#endif /* #ifndef _AUTOPILOT_TECH_H_ */

