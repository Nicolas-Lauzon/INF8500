#include "arguments.h"
#include "definitions.h"

#include <cstdio>
#include <iostream>
#include <windows.h>

HANDLE m_threads[3];
sender_type sender_info;
reader_type reader_info;
reader_type camera_info;

long unsigned int WINAPI sender(void*);
long unsigned int WINAPI reader(void*);
long unsigned int WINAPI camera(void*);
void create_thread(HANDLE* thread, long unsigned int(WINAPI* start_routine)(void*), void* data);
BOOL WINAPI keyboard_handler(DWORD);
void console_handlers();

int main(int argc, char* argv[]) {
    if (!SetConsoleCtrlHandler((PHANDLER_ROUTINE)keyboard_handler, TRUE)) {
        fprintf(stderr, "Unable to install handler!\n");
        return EXIT_FAILURE;
    }

    arguments argument_parser(argc, argv);
    if (argument_parser.has_error()) {
        printf("%s", argument_parser.get_error().c_str());
        return 1;
    }

	if (argument_parser.is_simulated_camera())
		printf("TCP/IP server for LineTracker with simulated camera\n");
	else
		printf("TCP/IP server for LineTracker with connected TCP/IP camera connected to the physical board\n");

    sender_info = {argument_parser.get_ip(), "5015", 320, 240, 20, argument_parser.get_vision_path(), argument_parser.is_simulated_camera(), console_handlers};
    reader_info = {argument_parser.get_ip(), "5016", 320 / 2, 240 / 2, true};
    //camera_info = {argument_parser.get_ip(), "28017", 320 / 2, 240 / 2, argument_parser.is_camera_feedback()};

    create_thread(&m_threads[0], &sender, (void*)&sender_info);
    create_thread(&m_threads[1], &reader, (void*)&reader_info);
    //create_thread(&m_threads[2], &camera, (void*)&camera_info);

	WaitForSingleObject(m_threads[0], INFINITE);
	WaitForSingleObject(m_threads[1], INFINITE);
	WaitForSingleObject(m_threads[2], INFINITE);

    return 0;
}

void create_thread(HANDLE* thread, long unsigned int(WINAPI* start_routine)(void*), void* data) {
    unsigned long descriptor;
    *thread = CreateThread(NULL, 0, start_routine, data, 0, &descriptor);

    if (thread == NULL) {
        std::cout << "error while creating thread" << std::endl;
    }
}

BOOL WINAPI keyboard_handler(DWORD type) {
    switch (type) {
    case CTRL_C_EVENT:
    case CTRL_BREAK_EVENT:
        console_handlers();
        break;
    default:
        break;
    }
    return TRUE;
}

void console_handlers() {
	sender_info.should_continue = false;
	reader_info.should_continue = false;
	camera_info.should_continue = false;
	
	if (sender_info.server_handler != 0) {
		closesocket(sender_info.server_handler->get_listen_socket());
		closesocket(sender_info.server_handler->get_socket());
	}
	if (reader_info.server_handler != 0) {
		closesocket(reader_info.server_handler->get_listen_socket());
		closesocket(reader_info.server_handler->get_socket());
	}
	if (camera_info.server_handler != 0) {
		closesocket(camera_info.server_handler->get_listen_socket());
		closesocket(camera_info.server_handler->get_socket());
	}
	CloseHandle(m_threads[0]);
	CloseHandle(m_threads[1]);
	CloseHandle(m_threads[2]);
}