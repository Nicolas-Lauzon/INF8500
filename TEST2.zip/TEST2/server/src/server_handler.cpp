#include "server_handler.h"

#include <cstdio>

server_handler::server_handler(const char* context, const char* server_ip, const char* port): m_context(context), m_server_ip(server_ip), m_port(port) {
    m_error = WSAStartup(MAKEWORD(2, 2), &m_wsa);
    if (m_error) {
        printf("%s WSAStartup failed with error: %d\n", m_context, m_error);
    }
}

server_handler::~server_handler() {
    shutdown(m_connect_socket, SD_BOTH);
    closesocket(m_listen_socket);
    closesocket(m_connect_socket);
    WSACleanup();
}

void server_handler::init() {
	    if (!has_error()) {
        m_error = do_init();

        if (has_error())
            printf("%s error during initialization\n", m_context);
    }
}

int server_handler::do_init() {
    struct addrinfo hints;
    struct addrinfo* result;

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;
    hints.ai_flags = AI_PASSIVE;

    int error = getaddrinfo(m_server_ip, m_port, &hints, &result);
    if (error != 0) {
        printf("%s getaddrinfo failed with error: %d\n", m_context, error);
        return error;
    }

    m_listen_socket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
    if (m_listen_socket == INVALID_SOCKET) {
        char *s = NULL;
        FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                    NULL, WSAGetLastError(),
                    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
                    (LPTSTR)&s, 0, NULL);
        printf("%s socket failed: %s\n", m_context, s);
        LocalFree(s);
        freeaddrinfo(result);
        return -1;
    }

    error = bind(m_listen_socket, result->ai_addr, (int)result->ai_addrlen);
        if (error == SOCKET_ERROR) {
            char *s = NULL;
        FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                    NULL, WSAGetLastError(),
                    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
                    (LPTSTR)&s, 0, NULL);
        printf("%s bind failed: %s\n", m_context, s);
        LocalFree(s);
        freeaddrinfo(result);
        closesocket(m_listen_socket);
        return -1;
    }

    freeaddrinfo(result);

    error = listen(m_listen_socket, SOMAXCONN);
    if (error == SOCKET_ERROR) {
        char *s = NULL;
        FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                    NULL, WSAGetLastError(),
                    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
                    (LPTSTR)&s, 0, NULL);
        printf("%s listen failed: %s\n", m_context, s);
        LocalFree(s);
        closesocket(m_listen_socket);
        return 1;
    }

    m_connect_socket = accept(m_listen_socket, NULL, NULL);
    if (m_connect_socket == INVALID_SOCKET) {
        /*char *s = NULL;
        FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                    NULL, WSAGetLastError(),
                    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
                    (LPTSTR)&s, 0, NULL);
        printf("%s accept failed: %s\n", m_context, s);
        LocalFree(s);*/
        closesocket(m_listen_socket);
        return 1;
    }

    closesocket(m_listen_socket);

    return 0;
}