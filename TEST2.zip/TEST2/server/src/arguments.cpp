#include "arguments.h"

#include <cstdio>

arguments::arguments(int argc, char* argv[]) {
	char buff[400];
	snprintf(buff, sizeof(buff), "Syntax: %s [SERVER_IP] [IS_SIMULATED_INPUT_CAMERA? true or false] [PATH TO SIMULATED INPUT CAMERA FILES] [IS_CAMERA_FEEDBACK? true or false]", argv[0]);
    if (argc != 5) {
        m_error_message = buff;
    } else {
		m_ip = argv[1];
		m_is_simulated_camera = strcmp(argv[2], "true") == 0;
		
		if (m_is_simulated_camera) {
			m_vision_path = argv[3];
		}
		
		m_is_camera_feedback = strcmp(argv[4], "true") == 0;
	}
}