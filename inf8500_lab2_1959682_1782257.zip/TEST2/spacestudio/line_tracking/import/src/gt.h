void reset_gt();
void start_gt();
void stop_gt();
void map_gt();
void unmap_gt();
unsigned long long get_time_gt();
