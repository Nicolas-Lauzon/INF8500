#ifndef SERVER_HANDLER_H
#define SERVER_HANDLER_H

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#define _WIN32_WINNT _WIN32_WINNT_WINXP
#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>

class server_handler {
  public:
    server_handler(const char* context, const char* server_ip, const char* port);
    ~server_handler();

    inline SOCKET get_socket() { return m_connect_socket; }
	inline SOCKET get_listen_socket() { return m_listen_socket; }
    inline bool has_error() { return m_error; }
	void init();

  private:

	int do_init();
    SOCKET m_connect_socket;
    SOCKET m_listen_socket;
    WSADATA m_wsa;
    const char* m_context;
	const char* m_server_ip;
	const char* m_port;
    int m_error;
};

#endif