#ifndef DEFINITIONS_H
#define DEFINITIONS_H

#include "server_handler.h"

#include <string>
#include <functional>

typedef union {
    unsigned char bytes[4];
    unsigned short half_word[2];
    unsigned long value;
} record_32;

typedef struct {
    std::string server_ip;
    std::string port;
    unsigned long width;
    unsigned long height;
    unsigned long number_of_frames;
    std::string basepath;
	bool should_continue;
	std::function<void(void)> close_handlers;
	server_handler* server_handler;
} sender_type;

typedef struct {
    std::string server_ip;
    std::string port;
    unsigned long width;
    unsigned long height;
    bool should_continue;
	server_handler* server_handler;
} reader_type;

#endif