Voici comment compiler et simuler pour le lab 3 INF8500:

1) D�marrez QuestaSim
2) Dans la fen�tre Principale de QuestaSim, placez-vous dans le r�pertoire Code_de_depart (via File -> Change Directory)
3) Dans la fen�tre Transcript tapez la commande do sim.do

Pensez à regarder la vidéo Youtube qui contient toutes les instructions.

Guy Bois
Julien Posso